<?php

class DefaultPresenter extends BasePresenter
{
    private $model;

    public function startup()
    {
        parent::startup();
        $this->model = new DefaultModel();
    }

    public function actionDefault()
    {
        $this->model->send(array('peci1@seznam.cz'), 'Ahoj lidi');
    }

    public function renderDefault()
    {
        $this->template->result = is_array($this->model->getResult()) ? 
            'Email se nepovedlo odeslat na následující adresy: ' . implode(',', $this->model->getResult()) : 
            ($this->model->getResult() ? 
                "Email byl odeslán" :
                "Email se nepovedlo odeslat");
    }
}

/* ?> ommitted intentionally */
