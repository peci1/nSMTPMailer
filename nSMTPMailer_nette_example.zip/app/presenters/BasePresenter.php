<?php




/**
  * BasePresenter 
  * 
  * defaultni presenter dedeny vsemi pouzitymi v aplikaci
  *
  * @copyright (c) 2009 Martin Pecka (Clevis)
  * @author Martin Pecka <martin.pecka@clevis.cz> 
 */
abstract class BasePresenter extends /*Nette\Application\*/Presenter
{

	/**
	  * startup 
	  * 
	  * provede zakladni nastaveni spolecna pro vsechny presentery
	  *
	  * @return void
	 */
	protected function startup()
	{

	}



	/**
	  * createTemplate 
	  * 
	  * defaultni akce pri vytvareni templatu (incudovani filtru...)
	  *
	  * @return void
	 */
	protected function createTemplate()
	{
		$template = parent::createTemplate();
		$template->registerFilter('Nette\Templates\CurlyBracketsFilter::invoke');
		return $template;
	}

}
