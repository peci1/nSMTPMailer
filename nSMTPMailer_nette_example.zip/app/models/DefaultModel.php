<?php

class DefaultModel
{
    private $result = '';
    public function send(array $recipients, $body) {

        $conf = Environment::getConfig('mail');

        $mail = new Mail();

        //here is the nSMTPMailer setup (loaded from config.ini)!!!
        $mailer = new SmtpMailer($conf['host'], $conf['port'], 
            $conf['transport'], $conf['username'], $conf['password']);        
        $mail->setMailer($mailer); //important!!!

        $mail->setFrom($conf['from']);

        $undelivered = array();
        foreach ($recipients as $email) {
            try {
                if (!preg_match('/^\s*$/', $email))
                    $mail->addTo($email);
            } catch (InvalidArgumentException $e) {
                $undelivered[] = $email;
            }
        }

        $mail->setSubject('Great mail');

        $mail->setBody($body);

        try {
            $mail->send();
            $undelivered = array_merge(
                $undelivered, 
                $mailer->getUndeliveredRecipients());

            if (count($undelivered) > 0)
                $this->result = $undelivered;
            else
                $this->result = TRUE;
        } catch (InvalidStateException $e) {
            $this->result = FALSE;
        }

    }

    public function getResult()
    {
        return $this->result;
    }
}

?>
