This is the app folder from default Nette structure.
You will need also document_root and libs.
In libs you will need to have Nette and nSMTPMailer copied
